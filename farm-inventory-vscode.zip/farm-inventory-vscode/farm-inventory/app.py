"""Farm Inventory: Flask + SQLite with its own login database.
Run:  python app.py            (this computer only)
      python app.py --lan      (other devices on your network can connect)
"""
import os, sqlite3, secrets, sys, time
from datetime import date
from functools import wraps
from flask import Flask, g, render_template, request, redirect, url_for, session, flash, abort
from markupsafe import Markup
from werkzeug.security import generate_password_hash, check_password_hash

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "farm.db")
KEYFILE = os.path.join(BASE, "secret.key")
if not os.path.exists(KEYFILE):
    with open(KEYFILE, "w") as f:
        f.write(secrets.token_hex(32))
app = Flask(__name__)
app.secret_key = open(KEYFILE).read()
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")

CATS = ["Seed", "Fertilizer", "Feed", "Chemicals", "Fuel", "Tools", "Other"]
SECTIONS = {
    "stock": dict(title="Stock items", req=["name"], fields=[
        ("name", "Item", "text", None), ("cat", "Category", "select", CATS),
        ("unit", "Unit (kg, bags, L)", "text", None), ("qty", "Quantity", "number", None),
        ("low", "Low-stock level", "number", None), ("cost", "Cost per unit", "number", None)]),
    "livestock": dict(title="Livestock", req=["species"], fields=[
        ("species", "Animal type", "text", None), ("tag", "Batch or tag", "text", None),
        ("heads", "Number of animals", "number", None), ("loc", "Location", "text", None),
        ("status", "Status", "select", ["Healthy", "Sick", "Sold", "Deceased"])]),
    "crops": dict(title="Crops", req=["crop"], fields=[
        ("crop", "Crop", "text", None), ("field", "Field", "text", None),
        ("area", "Area (ha)", "number", None), ("planted", "Planted", "date", None),
        ("harvest", "Expected harvest", "date", None),
        ("status", "Stage", "select", ["Planned", "Growing", "Harvested"])]),
    "meds": dict(title="Medication", req=["animal", "med"], fields=[
        ("day", "Date given", "date", None), ("animal", "Animal or batch", "text", None),
        ("med", "Medication", "text", None), ("dose", "Dose", "text", None),
        ("given_by", "Given by", "text", None), ("wd", "Withdrawal ends", "date", None),
        ("notes", "Notes", "text", None)]),
}
SCHEMA = """
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, name TEXT, pw_hash TEXT NOT NULL, role TEXT NOT NULL, last_login TEXT);
CREATE TABLE IF NOT EXISTS stock(id INTEGER PRIMARY KEY, name TEXT NOT NULL, cat TEXT, unit TEXT, qty REAL DEFAULT 0, low REAL DEFAULT 0, cost REAL DEFAULT 0, by_user TEXT);
CREATE TABLE IF NOT EXISTS moves(id INTEGER PRIMARY KEY, day TEXT, item_id INTEGER, kind TEXT, qty REAL, note TEXT, by_user TEXT);
CREATE TABLE IF NOT EXISTS livestock(id INTEGER PRIMARY KEY, species TEXT NOT NULL, tag TEXT, heads REAL DEFAULT 0, loc TEXT, status TEXT, by_user TEXT);
CREATE TABLE IF NOT EXISTS crops(id INTEGER PRIMARY KEY, crop TEXT NOT NULL, field TEXT, area REAL DEFAULT 0, planted TEXT, harvest TEXT, status TEXT, by_user TEXT);
CREATE TABLE IF NOT EXISTS meds(id INTEGER PRIMARY KEY, day TEXT, animal TEXT NOT NULL, med TEXT NOT NULL, dose TEXT, given_by TEXT, wd TEXT, notes TEXT, by_user TEXT);
"""
FAILS = {}

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(_):
    d = g.pop("db", None)
    if d:
        d.close()

def q(sql, *a):
    return db().execute(sql, a).fetchall()

def today():
    return date.today().isoformat()

@app.template_filter("num")
def num(v):
    try:
        return f"{float(v):,.2f}".rstrip("0").rstrip(".")
    except (TypeError, ValueError):
        return v or ""

@app.before_request
def guards():
    if request.method == "POST":
        if not secrets.compare_digest(request.form.get("csrf", ""), session.get("csrf", "")):
            abort(400)
    uid = session.get("uid")
    g.user = db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone() if uid else None

@app.context_processor
def inject():
    tok = session.setdefault("csrf", secrets.token_hex(16))
    nav = [("/", "Summary"), ("/s/stock", "Stock"), ("/moves", "Stock in/out"),
           ("/s/livestock", "Livestock"), ("/s/crops", "Crops"), ("/s/meds", "Medication")]
    if g.get("user") and g.user["role"] == "admin":
        nav.append(("/users", "Users"))
    return dict(user=g.get("user"), nav=nav, today=today(),
                csrf_field=lambda: Markup(f'<input type="hidden" name="csrf" value="{tok}">'))

def login_required(f):
    @wraps(f)
    def w(*a, **k):
        if not g.user:
            return redirect(url_for("login"))
        return f(*a, **k)
    return w

def admin_required(f):
    @wraps(f)
    def w(*a, **k):
        if not g.user or g.user["role"] != "admin":
            abort(403)
        return f(*a, **k)
    return w

def start_session(uid):
    session.clear()
    session["uid"] = uid
    session["csrf"] = secrets.token_hex(16)
    db().execute("UPDATE users SET last_login=? WHERE id=?", (time.strftime("%Y-%m-%d %H:%M"), uid))
    db().commit()

# ---------- login ----------
@app.route("/setup", methods=["GET", "POST"])
def setup():
    if q("SELECT 1 FROM users LIMIT 1"):
        return redirect(url_for("login"))
    if request.method == "POST":
        u, p = request.form["username"].strip().lower(), request.form["password"]
        if not u or len(p) < 6:
            flash("Enter a username and a password of at least 6 characters.")
        else:
            cur = db().execute("INSERT INTO users(username,name,pw_hash,role) VALUES(?,?,?,'admin')",
                               (u, request.form.get("name", "").strip(), generate_password_hash(p)))
            db().commit()
            start_session(cur.lastrowid)
            return redirect(url_for("dash"))
    return render_template("login.html", setup=True)

@app.route("/login", methods=["GET", "POST"])
def login():
    if not q("SELECT 1 FROM users LIMIT 1"):
        return redirect(url_for("setup"))
    if request.method == "POST":
        ip, now = request.remote_addr, time.time()
        FAILS[ip] = [t for t in FAILS.get(ip, []) if now - t < 300]
        if len(FAILS[ip]) >= 5:
            flash("Too many failed attempts. Please wait 5 minutes.")
        else:
            row = db().execute("SELECT * FROM users WHERE username=?",
                               (request.form["username"].strip().lower(),)).fetchone()
            if row and check_password_hash(row["pw_hash"], request.form["password"]):
                start_session(row["id"])
                return redirect(url_for("dash"))
            FAILS[ip].append(now)
            flash("Wrong username or password.")
    return render_template("login.html", setup=False)

@app.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

# ---------- summary ----------
@app.route("/")
@login_required
def dash():
    live = "status NOT IN ('Sold','Deceased')"
    d = dict(
        n_stock=q("SELECT COUNT(*) c FROM stock")[0]["c"],
        low=q("SELECT * FROM stock WHERE low>0 AND qty<=low ORDER BY name"),
        value=q("SELECT COALESCE(SUM(qty*cost),0) v FROM stock")[0]["v"],
        animals=q(f"SELECT COALESCE(SUM(heads),0) v FROM livestock WHERE {live}")[0]["v"],
        by_species=q(f"SELECT species, SUM(heads) n FROM livestock WHERE {live} GROUP BY species"),
        by_cat=q("SELECT cat, COUNT(*) n, SUM(qty*cost) v FROM stock GROUP BY cat"),
        crops=q("SELECT * FROM crops WHERE status!='Harvested' ORDER BY harvest"),
        hold=q("SELECT * FROM meds WHERE wd!='' AND wd>=? ORDER BY wd", today()),
        recent=q("SELECT m.*, s.name item, s.unit FROM moves m LEFT JOIN stock s ON s.id=m.item_id ORDER BY m.id DESC LIMIT 5"))
    return render_template("dash.html", **d)

# ---------- generic sections ----------
def clean(v, typ):
    v = (v or "").strip()
    if typ == "number":
        try:
            return max(float(v), 0)
        except ValueError:
            return 0
    return v

@app.route("/s/<key>")
@login_required
def section(key):
    s = SECTIONS.get(key) or abort(404)
    rows = q(f"SELECT * FROM {key} ORDER BY id DESC")
    return render_template("section.html", key=key, s=s, rows=rows)

@app.post("/s/<key>/add")
@login_required
def add(key):
    s = SECTIONS.get(key) or abort(404)
    if any(not request.form.get(c, "").strip() for c in s["req"]):
        flash("Please fill in the required fields.")
        return redirect(url_for("section", key=key))
    cols = [f[0] for f in s["fields"]] + ["by_user"]
    vals = [clean(request.form.get(f[0]), f[2]) for f in s["fields"]] + [g.user["username"]]
    db().execute(f"INSERT INTO {key}({','.join(cols)}) VALUES({','.join('?' * len(cols))})", vals)
    db().commit()
    return redirect(url_for("section", key=key))

@app.post("/s/<key>/<int:rid>/delete")
@admin_required
def delete(key, rid):
    SECTIONS.get(key) or abort(404)
    db().execute(f"DELETE FROM {key} WHERE id=?", (rid,))
    db().commit()
    return redirect(url_for("section", key=key))

# ---------- stock in/out ----------
@app.route("/moves")
@login_required
def moves():
    return render_template("moves.html", items=q("SELECT * FROM stock ORDER BY name"),
        rows=q("SELECT m.*, s.name item, s.unit FROM moves m LEFT JOIN stock s ON s.id=m.item_id ORDER BY m.id DESC"))

@app.post("/moves/add")
@login_required
def moves_add():
    try:
        item, qty = int(request.form["item"]), float(request.form["qty"])
    except (KeyError, ValueError):
        abort(400)
    kind = "in" if request.form.get("kind") == "in" else "out"
    s = db().execute("SELECT * FROM stock WHERE id=?", (item,)).fetchone() or abort(404)
    if qty <= 0:
        flash("Enter a quantity above zero.")
    elif kind == "out" and qty > s["qty"]:
        flash(f"Only {num(s['qty'])} {s['unit']} of {s['name']} in stock.")
    else:
        db().execute("UPDATE stock SET qty=qty+? WHERE id=?", (qty if kind == "in" else -qty, item))
        db().execute("INSERT INTO moves(day,item_id,kind,qty,note,by_user) VALUES(?,?,?,?,?,?)",
                     (request.form.get("day") or today(), item, kind, qty,
                      request.form.get("note", "").strip(), g.user["username"]))
        db().commit()
    return redirect(url_for("moves"))

@app.post("/moves/<int:rid>/delete")
@admin_required
def moves_delete(rid):
    m = db().execute("SELECT * FROM moves WHERE id=?", (rid,)).fetchone() or abort(404)
    db().execute("UPDATE stock SET qty=qty+? WHERE id=?", (-m["qty"] if m["kind"] == "in" else m["qty"], m["item_id"]))
    db().execute("DELETE FROM moves WHERE id=?", (rid,))
    db().commit()
    return redirect(url_for("moves"))

# ---------- users (admin) ----------
@app.route("/users")
@admin_required
def users():
    return render_template("users.html", rows=q("SELECT * FROM users ORDER BY username"))

@app.post("/users/add")
@admin_required
def users_add():
    u, p = request.form["username"].strip().lower(), request.form["password"]
    if not u or len(p) < 6:
        flash("Enter a username and a password of at least 6 characters.")
    else:
        try:
            db().execute("INSERT INTO users(username,name,pw_hash,role) VALUES(?,?,?,?)",
                         (u, request.form.get("name", "").strip(), generate_password_hash(p),
                          "admin" if request.form.get("role") == "admin" else "worker"))
            db().commit()
        except sqlite3.IntegrityError:
            flash("That username already exists.")
    return redirect(url_for("users"))

@app.post("/users/<int:uid>/password")
@admin_required
def users_password(uid):
    p = request.form["password"]
    if len(p) < 6:
        flash("Use at least 6 characters.")
    else:
        db().execute("UPDATE users SET pw_hash=? WHERE id=?", (generate_password_hash(p), uid))
        db().commit()
        flash("Password changed.")
    return redirect(url_for("users"))

@app.post("/users/<int:uid>/delete")
@admin_required
def users_delete(uid):
    if uid == g.user["id"]:
        flash("You cannot delete your own account.")
    else:
        db().execute("DELETE FROM users WHERE id=?", (uid,))
        db().commit()
    return redirect(url_for("users"))

with sqlite3.connect(DB) as _c:
    _c.executescript(SCHEMA)

if __name__ == "__main__":
    lan = "--lan" in sys.argv
    app.run(host="0.0.0.0" if lan else "127.0.0.1", port=5000, debug=False)
